package net.javacode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(AppDemo1Application.class, args);
	}

}
